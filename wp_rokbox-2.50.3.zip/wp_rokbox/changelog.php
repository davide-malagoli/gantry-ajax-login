<?php
/**
 * @version   2.50.3 March 4, 2014
 * @author    RocketTheme, LLC http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2014 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
die();
?>

Legend:

* -> Security Fix
# -> Bug Fix
+ -> Addition
^ -> Change
- -> Removed
! -> Note

------- 2.50.2 Release [] ------
# Backwards Compatibility filters are fired much later adding support to ie. RokGallery

------- 2.50.1 Release [] ------
# Fixed the issue that could prevent vertical scrolling in SideMenu in Gantry