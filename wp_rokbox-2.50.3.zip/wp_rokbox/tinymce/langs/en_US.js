// English lang variables for WP2.5

tinyMCE.addI18n({en_US:{
    RokBox:{
        desc : 'Add RokBox'
    }}});
